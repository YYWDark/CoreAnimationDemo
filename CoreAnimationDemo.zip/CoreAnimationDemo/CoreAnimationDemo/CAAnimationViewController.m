//
//  CAAnimationViewController.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/21.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "CAAnimationViewController.h"
static const NSTimeInterval timeIntrval = 6.0f;
static const CGFloat side = 100.0f;
static const CGFloat distance = 50.0f;
static const CGFloat originY = 100.0f;
static const CGFloat fontSize = 20.0;

@interface CAAnimationViewController ()
@end

@implementation CAAnimationViewController
- (void)viewDidLoad {
    self.view.backgroundColor = [UIColor whiteColor];
//    CAAnimation *animation = [CAAnimation animation];
//    CAMediaTimingFunction *timing =  [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
//    self.colorLayer = [CALayer layer];
//    self.colorLayer.frame = CGRectMake(0, 0, 100, 100);
//    self.colorLayer.position = CGPointMake(self.view.bounds.size.width/2.0, self.view.bounds.size.height/2.0);
//    self.colorLayer.backgroundColor = [UIColor redColor].CGColor;
//    [self.view.layer addSublayer:self.colorLayer];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self testkCAMediaTimingFunctionLinear];
        [self testkCAMediaTimingFunctionEaseIn];
        [self testkCAMediaTimingFunctionEaseOut];
        [self testkCAMediaTimingFunctionEaseInEaseOut];
        [self testkCAMediaTimingFunctionDefault];
    });
   

}

- (void)testkCAMediaTimingFunctionLinear{
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, originY, self.view.frame.size.width, side)];
    infoLabel.text = @"kCAMediaTimingFunctionLinear";
    infoLabel.font = [UIFont systemFontOfSize:fontSize];
    infoLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:infoLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"五角星"]];
    imageView.frame = CGRectMake(0, originY, side, side);
    [self.view addSubview:imageView];
    [self addAnimationTimingID:kCAMediaTimingFunctionLinear targetView:imageView];
  
}

- (void)testkCAMediaTimingFunctionEaseIn{
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, originY + side + distance, self.view.frame.size.width, side)];
    infoLabel.text = @"kCAMediaTimingFunctionEaseIn";
    infoLabel.font = [UIFont systemFontOfSize:fontSize];
    infoLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:infoLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"帽子"]];
    imageView.frame = CGRectMake(0, originY + side + distance, side, side);
    [self.view addSubview:imageView];
    
    [self addAnimationTimingID:kCAMediaTimingFunctionEaseIn targetView:imageView];
}

- (void)testkCAMediaTimingFunctionEaseOut{
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, originY + 2*(side + distance), self.view.frame.size.width, side)];
    infoLabel.text = @"kCAMediaTimingFunctionEaseOut";
    infoLabel.font = [UIFont systemFontOfSize:fontSize];
    infoLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:infoLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"圣诞老公公"]];
    imageView.frame = CGRectMake(0, originY + 2*(side + distance), side, side);
    [self.view addSubview:imageView];
    
    [self addAnimationTimingID:kCAMediaTimingFunctionEaseOut targetView:imageView];
}

- (void)testkCAMediaTimingFunctionEaseInEaseOut{
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, originY + 3*(side + distance), self.view.frame.size.width, side)];
    infoLabel.text = @"kCAMediaTimingFunctionEaseInEaseOut";
    infoLabel.font = [UIFont systemFontOfSize:fontSize];
    infoLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:infoLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"圣诞老人"]];
    imageView.frame = CGRectMake(0, originY + 3*(side + distance), side, side);
    [self.view addSubview:imageView];
    
     [self addAnimationTimingID:kCAMediaTimingFunctionEaseInEaseOut targetView:imageView];
}

- (void)testkCAMediaTimingFunctionDefault{
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, originY + 4*(side + distance), self.view.frame.size.width, side)];
    infoLabel.text = @"kCAMediaTimingFunctionDefault";
    infoLabel.font = [UIFont systemFontOfSize:fontSize];
    infoLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:infoLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"雪人"]];
    imageView.frame = CGRectMake(0, originY + 4*(side + distance), side, side);
    [self.view addSubview:imageView];
    
     [self addAnimationTimingID:kCAMediaTimingFunctionDefault targetView:imageView];
}

- (void)addAnimationTimingID:(NSString *)timingFunction targetView:(UIView *)targetView{
    CABasicAnimation *basicAnimation  = [[CABasicAnimation alloc] init];
    basicAnimation.timingFunction = [CAMediaTimingFunction functionWithName:timingFunction];
    basicAnimation.keyPath = @"position.x";
    basicAnimation.byValue = @(self.view.frame.size.width - side);
    basicAnimation.repeatCount = 1000;
    basicAnimation.duration = timeIntrval;
    basicAnimation.delegate = self;
    [targetView.layer addAnimation:basicAnimation forKey:@"positionX"];
}


#pragma  mark - CAAnimationDelegate
- (void)animationDidStart:(CAAnimation *)anim{
    NSLog(@"动画开始");
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
   
   /*
    因为我们的动画repeatCount属性设置成了1000。所以会很久才结束。你可以手动修改
    你可以根据"key值来判断是哪个layer上的动画"
    比如：[XXX.arrowLayer animationForKey:@"positionX"]拿到动画
    动画结束后建议为layer使用removeAllAnimations移除相应的动画
    */
   NSLog(@"动画结束");
}





@end
