//
//  LayerTreeViewController.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/17.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "LayerTreeViewController.h"

@interface LayerTreeViewController ()
@property (nonatomic, strong) UIView *redView;
@end

@implementation LayerTreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.redView.layer.position = CGPointMake(100, 100);
    [self printMethod];
    
    CABasicAnimation *basicAnimation  = [[CABasicAnimation alloc] init];
    basicAnimation.keyPath = @"position.y";
    basicAnimation.fromValue = @0;
    basicAnimation.toValue = @500;
    basicAnimation.duration = 10;
    [self.redView.layer addAnimation:basicAnimation forKey:@"positionY"];
    
 
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                                      target:self
                                                    selector:@selector(printMethod)
                                                    userInfo:nil
                                                     repeats:YES];
    [timer fire];
    
    
}


- (void)printMethod{
    CALayer *modelLayer = self.redView.layer;
    CALayer *presentationLayer = self.redView.layer.presentationLayer;
    NSLog(@"model layer:%@   presentation layer :%@", NSStringFromCGPoint(modelLayer.position),NSStringFromCGPoint(presentationLayer.position));
}

#pragma mark - get
- (UIView *)redView{
    if (!_redView) {
        _redView = [[UIView alloc] init];
        _redView.frame = CGRectMake(0, 0, 100, 100);
        _redView.backgroundColor = [UIColor redColor];
        _redView.center = self.view.center;
        [self.view addSubview:_redView];
        [self printMethod];
    }
    return _redView;
}
@end
