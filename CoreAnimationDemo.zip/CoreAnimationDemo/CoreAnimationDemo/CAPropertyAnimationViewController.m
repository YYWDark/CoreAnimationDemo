//
//  CAAnimationViewController.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/17.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "CAPropertyAnimationViewController.h"
static const NSTimeInterval timeIntrval = 3.0f;

@interface CAPropertyAnimationViewController ()
@property (nonatomic, strong) UIView *redView;
@end

@implementation CAPropertyAnimationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self animation3D];
    [self animationPositionY];
    [self animationScale];
    [self animationGroup];
     
}

- (void)animation3D{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"五角星"]];
    imageView.frame = CGRectMake(10, 100, 100, 100);
    [self.view addSubview:imageView];
    
    CABasicAnimation *basicAnimation  = [[CABasicAnimation alloc] init];
    basicAnimation.keyPath = @"transform";
    //保持动画后的最后状态
    basicAnimation.fillMode = kCAFillModeForwards;
    basicAnimation.removedOnCompletion = NO;
    //执行完执行逆动画
    basicAnimation.autoreverses = YES;
    basicAnimation.removedOnCompletion = NO;
    CATransform3D fromValue =imageView.layer.transform;
    //设置动画开始的属性值
    basicAnimation.fromValue = [NSValue valueWithCATransform3D:fromValue];
    // 绕X轴旋转180度
    CATransform3D toValue =CATransform3DRotate(fromValue, M_PI , 0 , 1 , 0);
    basicAnimation.toValue = [NSValue valueWithCATransform3D:toValue];
    basicAnimation.repeatCount = 1000;
    basicAnimation.duration = timeIntrval;
    [imageView.layer addAnimation:basicAnimation forKey:@"positionY"];
}

- (void)animationPositionY{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"飞机"]];
    imageView.frame = CGRectMake(10, 410, 100, 100);
    [self.view addSubview:imageView];
    
    CABasicAnimation *basicAnimation  = [[CABasicAnimation alloc] init];
    basicAnimation.keyPath = @"position.y";
    basicAnimation.autoreverses = YES;
    //设置动画开始的属性值
    basicAnimation.fromValue = @(imageView.frame.origin.y);
    basicAnimation.toValue = @(imageView.frame.origin.y - 100);
    basicAnimation.repeatCount = 1000;
    basicAnimation.duration = timeIntrval;
    [imageView.layer addAnimation:basicAnimation forKey:@"positionY"];
}

- (void)animationScale{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"帽子"]];
    imageView.frame = CGRectMake(0, 0, 100, 100);
    imageView.center = self.view.center;
    [self.view addSubview:imageView];
    
    CABasicAnimation *basicAnimation  = [[CABasicAnimation alloc] init];
    basicAnimation.keyPath = @"transform.scale";
    basicAnimation.autoreverses = YES;
    //设置动画开始的属性值
    basicAnimation.fromValue = @(1.0);
    basicAnimation.toValue = @(.5);
    basicAnimation.repeatCount = 1000;
    basicAnimation.duration = timeIntrval;
    [imageView.layer addAnimation:basicAnimation forKey:@"positionY"];
}

- (void)animationGroup{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"火箭"]];
    imageView.frame = CGRectMake(0, self.view.frame.size.height - 100, 100, 100);
    [self.view addSubview:imageView];
    
    CABasicAnimation *positionAnimation  = [[CABasicAnimation alloc] init];
    positionAnimation.keyPath = @"position";
    positionAnimation.toValue = [NSValue valueWithCGPoint:CGPointMake(self.view.frame.size.width - 50, 100)];
    
    CABasicAnimation *transformAnimation =
    [CABasicAnimation animationWithKeyPath:@"transform"];
    

    CATransform3D fromValue = imageView.layer.transform;
    //设置动画开始的属性值
    transformAnimation.fromValue = [NSValue valueWithCATransform3D:fromValue];
    CATransform3D toValue =CATransform3DRotate(fromValue, M_PI/4 , 1 , 1 , 1);
    transformAnimation.toValue = [NSValue valueWithCATransform3D:toValue];
    /* 动画组 */
    CAAnimationGroup *group = [CAAnimationGroup animation];
    
    // 动画选项设定
    group.duration = timeIntrval *1.5;
    group.repeatCount = 1000;
    group.autoreverses = YES;
    group.animations = [NSArray arrayWithObjects:positionAnimation, transformAnimation, nil];
    [imageView.layer addAnimation:group forKey:@"move-rotate-layer"];
}
#pragma mark - privatr method
- (CGPathRef)_getPathRefWithRect:(CGRect)rect{
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(200, 200) radius:80 startAngle:0 endAngle:M_PI*2 clockwise:NO];;
    return [path CGPath];
}

#pragma mark - red
- (UIView *)redView{
    if (!_redView) {
        _redView = [[UIView alloc] init];
        _redView.frame = CGRectMake(0, 0, 100, 100);
        _redView.backgroundColor = [UIColor redColor];
        _redView.center = self.view.center;
        [self.view addSubview:_redView];
    }
    return _redView;
}
@end
