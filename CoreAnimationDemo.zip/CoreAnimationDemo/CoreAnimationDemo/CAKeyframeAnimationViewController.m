//
//  CAKeyframeAnimationViewController.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/17.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "CAKeyframeAnimationViewController.h"
static const CGFloat side = 50.0f;
@implementation CAKeyframeAnimationViewController
- (void)viewDidLoad {
    [super viewDidLoad];
     self.view.backgroundColor = [UIColor whiteColor];
     
    [self animationWithValues];
    [self animationWithPath];
    
}

- (CGPathRef)_getPathRefWithRect{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(100, 100)];
    [path addLineToPoint:CGPointMake(self.view.frame.size.width - 100, 100)];
    [path addLineToPoint:CGPointMake(self.view.frame.size.width - 100, 200)];
    [path addLineToPoint:CGPointMake(100, 200)];
     [path addLineToPoint:CGPointMake(100, 100)];
    //边框线宽
    return [path CGPath];
}


- (void)animationWithPath{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"雪人"]];
    imageView.frame = CGRectMake(0, 0, side, side);
    [self.view addSubview:imageView];
    
    CAKeyframeAnimation *keyFrameAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    keyFrameAnimation.path = [self _getPathRefWithRect];

    keyFrameAnimation.duration = 5.0;
    keyFrameAnimation.repeatCount = 1000;
    keyFrameAnimation.additive = YES;
    //执行完执行逆动画
    keyFrameAnimation.autoreverses = YES;
    [imageView.layer addAnimation:keyFrameAnimation forKey:@"jump"];
}

- (void)animationWithValues{
    CGFloat distance = (self.view.frame.size.width - 4*side)/5;
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_QQ"]];
    imageView.frame = CGRectMake(distance, self.view.frame.size.height - side - 40, side, side);
    [self.view addSubview:imageView];
    
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_Qzone"]];
    imageView1.frame = CGRectMake(distance *2 + side, self.view.frame.size.height - side - 40, side, side);
    [self.view addSubview:imageView1];
    
    UIImageView *imageView2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_twitter"]];
    imageView2.frame = CGRectMake((distance + side)*2 +distance, self.view.frame.size.height - side - 40, side, side);
    [self.view addSubview:imageView2];
    
    UIImageView *imageView3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_weichat"]];
    imageView3.frame = CGRectMake((distance + side)*3 +distance, self.view.frame.size.height - side - 40, side, side);
    [self.view addSubview:imageView3];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        CAKeyframeAnimation *keyFrameAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position.y"];
        keyFrameAnimation.values = @[ @0, @(-20),@(-60),@(-20),@0];
        keyFrameAnimation.keyTimes = @[ @0, @(1/6.0),@(3/6.0),@(5/6.0),@1];
        keyFrameAnimation.duration = .6f;
        keyFrameAnimation.repeatCount = 2;
        keyFrameAnimation.additive = YES;
        [imageView.layer addAnimation:keyFrameAnimation forKey:@"jump"];
        
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 1;
        [imageView1.layer addAnimation:keyFrameAnimation forKey:@"jump"];
        
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 2;
        [imageView2.layer addAnimation:keyFrameAnimation forKey:@"jump"];
        
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 3;
        [imageView3.layer addAnimation:keyFrameAnimation forKey:@"jump"];
    });
  
    
}
@end
