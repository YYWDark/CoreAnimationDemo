//
//  CATransactionViewController.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/21.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "CATransactionViewController.h"

@interface CATransactionViewController ()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) CALayer *redLayer;
@end

@implementation CATransactionViewController
- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"圣诞老人"]];
    self.imageView.frame = CGRectMake(0, 0, 100, 100);
    self.imageView.center = self.view.center;
    [self.view addSubview:self.imageView];
    
    self.redLayer = [CALayer layer];
    self.redLayer.frame = CGRectMake(100, 100, 100, 100);
    self.redLayer.delegate = self;
    self.redLayer.backgroundColor = [UIColor redColor].CGColor;
    [self.view.layer addSublayer:self.redLayer];
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    configure the transaction
    [CATransaction begin];
//    [CATransaction setDisableActions:YES];
    [CATransaction setAnimationDuration:4.0];
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut]];
    //set the position
    self.redLayer.position  = [[touches anyObject] locationInView:self.view];
    self.imageView.layer.position = [[touches anyObject] locationInView:self.view];
   
    //commit transaction
    [CATransaction commit];
    
    
    NSLog(@"Outside: %@", [self.imageView actionForLayer:self.imageView.layer forKey:@"position"]);
    //begin animation block
    [UIView beginAnimations:nil context:nil];
    //test layer action when inside of animation block
    NSLog(@"Inside: %@", [self.imageView actionForLayer:self.imageView.layer forKey:@"position"]);
    //end animation block
    [UIView commitAnimations];
    
}



@end
