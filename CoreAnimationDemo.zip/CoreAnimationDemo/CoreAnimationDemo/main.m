//
//  main.m
//  CoreAnimationDemo
//
//  Created by wyy on 16/11/17.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
